1) Arrays Have O(1) Element Access, O(1a) front/back Insertion/Deletion, O(N) Insertion/Deletion At middle.
1) LL Have O(N) Element Access, O(1) front/back Insertion/Deletion, O(N) Insertion/Deletion in middle.
