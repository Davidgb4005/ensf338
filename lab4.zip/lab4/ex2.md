1) Array Size is number of elements -1 and capacity is current memory allocated but not initilized

2) when the Array is at max capacity it expands the array by a factor of n*k unless there is not enough contiguios memoroy
then it must copy and move to a space that does have enough

3) Expand the array by a factor of n^(1+k) aslong as k> 0 the complexity of will be N/n^(1+k) and will trend to O(1)