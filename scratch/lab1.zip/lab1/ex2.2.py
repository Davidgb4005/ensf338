def count_vowels():
    moby = open("pg2701.txt", 'r', encoding='utf-8') #make sure files in same directory
    vowels = ['a', 'e', 'i', 'o', 'u', 'y', 'A', 'E', 'I', 'O', 'U', 'Y']
    x = 3 #start at 3 to count vowels in chapter 1 line
    for line in moby:
        if 'CHAPTER 1. Loomings.' in line:
            break
    contents = moby.read()
    for char in contents:
        if char in vowels:
            x += 1
    print(x)
    moby.close()

count_vowels()
            
