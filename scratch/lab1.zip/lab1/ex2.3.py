import json
import math

def find_size(input_dict):
	if input_dict.keys() == None:
		return
	print(input_dict.keys())
	find_size(i)	

f = open("large-file.json", "r")
data = f.read()
json_data = json.loads(data)
temp_json ={}
a = 0
for i in json_data:
	print(i.keys())
	find_size(i)

g =open("large-file-new.json", "w")
json.dump(json_data,g,indent=4)
f.close()
	
