import timeit
def pow2_1(n):
    return 2 ** n
def pow2_2(n):
    x = 1
    for i in range(n):
        x *= 2
    return x
def pow2_3(n):
    x = 1
    pow_list = [x := x * 2 for i in range(n)]
    return pow_list[-1]

time_pow1 = timeit.timeit(lambda: pow2_1(10000), number=10000)

time_pow2 = timeit.timeit(lambda: pow2_2(1000), number=1000)

time_pow3 = timeit.timeit(lambda: pow2_3(1000), number=1000)

print(f'Time per loop of 1st function: {time_pow1:.6f} seconds')
print(f'Time per loop of 2nd function: {time_pow2:.6f} seconds')
print(f'Time per loop of 3rd function: {time_pow3:.6f} seconds')